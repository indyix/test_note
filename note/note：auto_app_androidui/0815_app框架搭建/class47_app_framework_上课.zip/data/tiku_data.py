
select_tiku_data = [
    {"tiku_name": "逻辑思维题", "expected": "逻辑思维题"}
]