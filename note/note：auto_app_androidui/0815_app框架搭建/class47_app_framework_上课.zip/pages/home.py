from common.basepage import BasePage


class HomePage(BasePage):

    pass