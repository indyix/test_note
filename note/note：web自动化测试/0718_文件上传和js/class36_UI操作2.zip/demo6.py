"""滑动到页面的最底部。"""

import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("https://readhub.cn/topics")

# 滑动到页面最底部

for i in range(3):
    js_code = 'window.scrollTo(0, document.body.scrollHeight);'
    driver.execute_script(js_code)

time.sleep(3)