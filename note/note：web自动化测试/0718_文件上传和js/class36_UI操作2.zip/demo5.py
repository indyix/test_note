import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("https://www.12306.cn/index/")


# 先定位 常见问题
el = driver.find_element_by_link_text("常见问题")
# 把 常见问题的元素 滑动的可见范围内
el.location_once_scrolled_into_view

el.click()

