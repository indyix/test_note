"""有时候，文件上传不是一个普通的input 元素，可能是其他的元素或者组件。。"""

import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("file:///D:/%E7%8F%AD%E7%BA%A7%E7%AE%A1%E7%90%86/python29%E6%9C%9F/class36_UI%E6%93%8D%E4%BD%9C2/demo.html")

# 上传文件 浏览器的指令
el = driver.find_element_by_name("mfile")
el.click()

time.sleep(1)

import pyautogui

# pyautogui.write("d:\demo.txt")
# pyautogui.press('enter', presses=2)
#
# time.sleep(2)

import pyautogui
import pyperclip

pyperclip.copy('D:\用户.txt')

time.sleep(2)
pyautogui.hotkey('ctrl', 'v')
pyautogui.press('enter', presses=2)

time.sleep(2)
