#!/usr/bin/env python3
#-*- coding:utf-8 -*-
# email: wagyu2016@163.com
# wechat: shoubian01
# author: 王雨泽

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("http://www.baidu.com")

e = driver.find_element_by_id("kw")

# 获取属性，但是设置属性
e.get_attribute()

# e.set_attribute()

def set_attribute(e):
    """设置e 的属性。

    传入 js 代码
    e.value = "柠檬班"

    e = document.getEelementById("kw")
    e.value = "柠檬班"
    """
    js_code = """e = document.getEelementById("kw");
    e.value = "柠檬班";
    """
    driver.execute_script(js_code)

