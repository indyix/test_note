"""有时候，文件上传不是一个普通的input 元素，可能是其他的元素或者组件。。"""

import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("file:///D:/%E7%8F%AD%E7%BA%A7%E7%AE%A1%E7%90%86/python29%E6%9C%9F/class36_UI%E6%93%8D%E4%BD%9C2/demo.html")

# 上传文件 浏览器的指令
el = driver.find_element_by_name("mfile")
el.click()

time.sleep(1)
# 操作系统的指令
from pywinauto import Desktop
app = Desktop()
dialog = app['打开']    #根据名字找到弹出窗口
dialog["Edit"].type_keys("D:\demo.txt")     # 在输入框中输入值
dialog["Button"].click()

time.sleep(2)

