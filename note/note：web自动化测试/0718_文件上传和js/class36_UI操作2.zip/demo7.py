"""滑动到页面的最底部。"""

import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("file:///D:/%E7%8F%AD%E7%BA%A7%E7%AE%A1%E7%90%86/python29%E6%9C%9F/class36_UI%E6%93%8D%E4%BD%9C2/demo.html")

# 上传文件
el = driver.find_element_by_name("mfile")

time.sleep(2)
# 输入的是文件的路径。
# send_keys: 1, 输入文本， 2， 可以输入键盘位置； 3， 发送文件
el.send_keys("d:\demo.txt")

time.sleep(3)
driver.quit()