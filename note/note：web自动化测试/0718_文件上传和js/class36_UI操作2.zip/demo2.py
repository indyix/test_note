#!/usr/bin/env python3
#-*- coding:utf-8 -*-
# email: wagyu2016@163.com
# wechat: shoubian01
# author: 王雨泽
import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("https://www.12306.cn/index/")

# 使用强制等待
time.sleep(1)

# 发送 js code 给浏览器
js_code = """e = document.getElementById("train_date");
e.readOnly = false;
e.value = "2020-07-20";"""
driver.execute_script(js_code)

time.sleep(5)
driver.quit()


