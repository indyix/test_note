import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("https://www.12306.cn/index/")

# 使用强制等待
time.sleep(1)

# e = driver.find_element_by_id("train_date")

# 发送 js code 给浏览器
js_code = """e = document.getElementById("train_date");"""
driver.execute_script(js_code)

time.sleep(0.2)
js_code = """e.readOnly = false;"""
driver.execute_script(js_code)

time.sleep(0.2)
js_code = """e.value = "2020-07-20";"""
driver.execute_script(js_code)

