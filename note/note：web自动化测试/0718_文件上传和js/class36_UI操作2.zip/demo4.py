import time

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions

driver = webdriver.Chrome()

driver.get("https://www.12306.cn/index/")

# 使用强制等待
time.sleep(1)

# 使用 python 定位到元素， python 对象 e
elem = driver.find_element_by_id("train_date")

# arguments[0] 相当于python format 占坑位
time.sleep(0.2)
js_code = """arguments[0].readOnly = false;"""
driver.execute_script(js_code, elem)

time.sleep(0.2)
js_code = """arguments[0].value = "2020-07-20";"""
driver.execute_script(js_code, elem)


