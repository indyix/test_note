"""投资用例"""
from middleware.pages.index import IndexPage


def test_invest_not_10_times(login):
    """投资不是 10 的整数倍。

    测试步骤：
        1， 前置条件：登录（）
            - 有钱
            - 有标可以投
            可以通过接口，可以通过修改数据库，可以手工充值，可以手工加标。
            - 每次你在执行之前都自动充值或者加一次标
            - 一次性满足条件

        2， 首页：点击抢投标
        3， 投标详情页：输入投标金额
        4， 投标详情页：获取结果
    """
    driver = login
    actual = IndexPage(driver).click_invest_btn().write_money(
        1).get_error_msg()
    assert actual == '请输入10的整数倍'


