from selenium.webdriver.common.by import By

from middleware.handler import Handler


class InvestPage:
    # 输入用户金额
    invest_input_locator = (By.CLASS_NAME, "form-control")

    # 投标按钮
    invest_btn_locator = (By.CLASS_NAME, 'btn-special')

    def __init__(self, driver):
        self.driver = driver

    def write_money(self, money):
        """输入用户金额"""
        self.driver.find_element(*self.invest_input_locator).send_keys(money)
        return self

    def get_error_msg(self):
        """不是10的整数倍错误信息"""
        el = self.driver.find_element(*self.invest_btn_locator)
        return el.text