"""运行测试用例"""

if __name__ == "__main__":
    pytest.main()
    