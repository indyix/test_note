
def test_demo_error():
    pass

def test_demo_success():
    pass


class TestDemo:

    def test_demo_no_class(self):
        pass
