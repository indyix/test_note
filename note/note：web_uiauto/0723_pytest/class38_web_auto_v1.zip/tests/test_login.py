"""登录功能的测试用例。"""
import pytest
from middleware.handler import Handler
from middleware.pages.login import LoginPage

# 读取 Excel 当中的数据
data = Handler.excel.read_data("login")


class TestLogin():
    """登录功能的测试类"""

    @pytest.mark.error_test
    @pytest.mark.parametrize("test_info", data)
    def test_login_error(self, test_info, driver):
        """
        1, 打开浏览器
        2，访问登录页面
        3，元素定位+元素操作（输入用户名和密码，点击登录）
        4，通过获取页面内容得到实际结果进行断言
        """
        # 打开浏览器

        # 1, 查找某个元素 def find(locator):
        # 2,  登录 def login(username, pwd):

        # 访问登录页面
        LoginPage(driver).login(
            username=eval(test_info["data"])["username"],
            password=eval(test_info["data"])["password"],
        )
        # 获取实际结果，断言
        actual = driver.find_element_by_class_name('form-error-info').text
        # self.assertEqual(actual, test_info["expected"])
        assert actual == test_info["expected"]
        # self.assertTrue(actual == "请输入手机号")




    # @pytest.mark.success
    # def test_login_success(self):
    #     """登录成功用例"""
    #      # 打开浏览器
    #     from selenium import webdriver
    #     driver = webdriver.Chrome()
    #     # driver.implicitly_wait(Handler.yaml["selenium"]["wait_time"])
    #     driver.implicitly_wait(WAIT_TIME)
    #
    #     # 访问登录页面
    #     url = "http://120.78.128.25:8765/Index/login.html"
    #     driver.get(url)
    #
    #     # 输入用户名和密码，提交
    #     driver.find_element_by_name("phone").send_keys("18684720553")
    #     driver.find_element_by_name("password").send_keys("python")
    #     driver.find_element_by_class_name("btn-special").click()
    #
    #      # 获取实际结果，断言
    #     actual = driver.find_element_by_xpath('//a[@href="/Member/index.html"]').text
    #     self.assertTrue("我的帐户[python]" in actual)
    #     # self.assertTrue(actual == "请输入手机号")
    #
    # def test_login_invalid(self):
    #     pass


