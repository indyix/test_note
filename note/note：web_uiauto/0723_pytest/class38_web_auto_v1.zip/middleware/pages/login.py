"""登录页面"""

class LoginPage:

    def __init__(self, driver):
        self.driver = driver

    def login(self, username, password):
        """登录行为"""
        url = "http://120.78.128.25:8765/Index/login.html"
        self.driver.get(url)

        # 输入用户名和密码，提交
        self.driver.find_element_by_name("phone").send_keys(username)
        self.driver.find_element_by_name("password").send_keys(password)
        self.driver.find_element_by_class_name("btn-special").click()

