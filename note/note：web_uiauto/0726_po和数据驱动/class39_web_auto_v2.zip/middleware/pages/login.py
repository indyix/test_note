"""登录页面"""
from middleware.pages.index import IndexPage
from middleware.handler import Handler


class LoginPage:

    URL = Handler.yaml["host"] + "/Index/login.html"
    # locators
    # login_btn_locator = ("name", "btn-special")
    # 登录按钮元素定位
    login_btn_locator = {"by": "name", "value": "special"}
    username_locator = {"by": "name", "value": "phone"}
    pwd_locator = {"by": "name", "value": "password"}
    error_msg_locator = {"by": "name", "value": "form-error-info"}

    def __init__(self, driver):
        self.driver = driver

    def get(self):
        """访问页面"""
        self.driver.get(self.URL)
        return self

    def login_fail(self, username, password):
        """登录行为。

        详细介绍这个函数是做什么用的，怎么使用，传什么参数，没个参数的意思，

        最后的返回值是什么，返回值代表什么意思。

        >>>oginPage(driver).login("yuz", "123")
        """

        self.enter_username(username)
        self.enter_password(password)

        # self.driver.find_element(*self.login_btn_locator).click()
        self.driver.find_element(**self.login_btn_locator).click()
        return self

    def login_success(self, username, password):

        self.enter_username(username)
        self.enter_password(password)

        self.driver.find_element(**self.login_btn_locator).click()
        return IndexPage(self.driver)

    def enter_username(self, username):
        """输入用户名"""
        self.driver.find_element(**self.username_locator).send_keys(username)
        return self

    def enter_password(self, pwd):
        """输入用户名"""
        self.driver.find_element(**self.pwd_locator).send_keys(pwd)
        return self

    def get_error_message(self):
        """获取登录不成功的错误信息"""
        return self.driver.find_element(**self.error_msg_locator).text
