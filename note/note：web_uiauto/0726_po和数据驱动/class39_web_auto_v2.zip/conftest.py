"""固定文件名 conftest.py.

存储所有的测试夹具。fixture
"""
import pytest

from config.config import WAIT_TIME


@pytest.fixture(scope="function")
def driver():
    """管理浏览器"""

    from selenium import webdriver
    driver = webdriver.Chrome()
    driver.implicitly_wait(WAIT_TIME)
    yield driver
    driver.quit()