"""浏览器的通用操作"""


class SeleniumHandler:
    pass